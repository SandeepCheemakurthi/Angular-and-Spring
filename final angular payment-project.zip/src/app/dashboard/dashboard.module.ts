import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Top5CustomerComponent } from './components/top5-customer/top5-customer.component';
import { Top5InstComponent } from './components/top5-inst/top5-inst.component';



@NgModule({
  declarations: [
    Top5CustomerComponent,
    Top5InstComponent
  ],
  imports: [
    CommonModule
  ]
})
export class DashboardModule { }
