import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Top5InstComponent } from './top5-inst.component';

describe('Top5InstComponent', () => {
  let component: Top5InstComponent;
  let fixture: ComponentFixture<Top5InstComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Top5InstComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Top5InstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
