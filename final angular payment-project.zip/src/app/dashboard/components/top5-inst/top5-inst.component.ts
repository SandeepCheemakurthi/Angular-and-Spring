import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top5-inst',
  templateUrl: './top5-inst.component.html',
  styleUrls: ['./top5-inst.component.css']
})
export class Top5InstComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
