import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top5-customer',
  templateUrl: './top5-customer.component.html',
  styleUrls: ['./top5-customer.component.css']
})
export class Top5CustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
