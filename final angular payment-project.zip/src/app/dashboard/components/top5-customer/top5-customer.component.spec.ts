import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Top5CustomerComponent } from './top5-customer.component';

describe('Top5CustomerComponent', () => {
  let component: Top5CustomerComponent;
  let fixture: ComponentFixture<Top5CustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Top5CustomerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Top5CustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
