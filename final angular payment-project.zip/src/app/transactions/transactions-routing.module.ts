import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CollectComponent } from './components/collect/collect.component';
import { SummaryComponent } from './components/summary/summary.component';
import { TransferComponent } from './components/transfer/transfer.component';


const routes: Routes = [ {
  path: 'transfer',
  component: TransferComponent,
},
{
  path: 'summary',
  component: SummaryComponent,
},
{
  path:'collect',
  component: CollectComponent
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TransactionsRoutingModule { }