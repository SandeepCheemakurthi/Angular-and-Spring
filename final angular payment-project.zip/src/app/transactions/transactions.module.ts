import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransferComponent } from './components/transfer/transfer.component';
import { TransactionsRoutingModule } from './transactions-routing.module';
import { SummaryComponent } from './components/summary/summary.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule } from '@angular/common/http';
import { PostDetailService } from './services/PostDetail.service';
import { CollectComponent } from './components/collect/collect.component';


@NgModule({
  declarations: [
    TransferComponent,
    SummaryComponent,
    CollectComponent
  ],
  imports: [CommonModule,TransactionsRoutingModule,FormsModule,HttpClientModule],
  exports: [TransferComponent,CollectComponent],
  providers: [PostDetailService,]
})
export class TransactionsModule { }
