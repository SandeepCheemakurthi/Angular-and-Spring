
import { HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Transfer } from '../models/transfer';



@Injectable({
  providedIn: 'root'
})
export class PostDetailService {

  private url = 'http://localhost:8080/transfers';


  constructor(private http: HttpClient) { }

  getDetails(): Observable<Transfer[]> {
    return this.http.get<Transfer[]>(`${this.url}`);
  }

  public doTransfer(transfer: Transfer){
    return this.http.post("http://localhost:8080/verify",transfer,{responseType:'text' as 'json'});
  }

  
}
