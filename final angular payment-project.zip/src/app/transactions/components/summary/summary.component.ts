import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {
 
    details: any =  {

    };

  constructor() { }

  ngOnInit(): void {
    this.details = JSON.parse(localStorage.getItem('userDetails')||'');
    console.log(this.details);
    return this.details;
    
  }
}
