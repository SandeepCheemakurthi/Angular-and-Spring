import { Component, OnInit } from '@angular/core';
import { Transfer } from '../../models/transfer';
import { PostDetailService } from '../../services/PostDetail.service';

@Component({
  selector: 'app-collect',
  templateUrl: './collect.component.html',
  styleUrls: ['./collect.component.css']
})
export class CollectComponent implements OnInit {

  transfer: Transfer = new Transfer();
  message: any;
  constructor(private postDetail: PostDetailService) { }

  ngOnInit(): void {
  }

  public startTransfer(){
    let resp=this.postDetail.doTransfer(this.transfer);
      resp.subscribe((data)=>this.message=data);
  }


}
