import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Transfer } from '../../models/transfer';
import { PostDetailService } from '../../services/PostDetail.service';



@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {

  
  transferDetails: Transfer[];

  constructor(private router: Router,private postService: PostDetailService ) { }

  ngOnInit(): void {
    this.postService.getDetails().subscribe((data: Transfer[]) => {
      console.log(data);
      this.transferDetails = data;
    })
  }
  
 /**  verification(){
    console.log(this.transferDetails);
    localStorage.setItem('userDetails', JSON.stringify(this.transferDetails));
  }*/

  

}


