export class Transfer {
    number: number;
    sender: string;
    amount: number;
    bic: string;
    bank: string;
    recevier: string;
}
