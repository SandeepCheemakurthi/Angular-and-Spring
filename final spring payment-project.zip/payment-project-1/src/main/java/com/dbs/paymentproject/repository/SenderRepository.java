package com.dbs.paymentproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dbs.paymentproject.model.sender;

public interface SenderRepository extends JpaRepository<sender, Integer> {

}
