package com.dbs.paymentproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dbs.paymentproject.model.Transfer;

public interface TransferRepository extends JpaRepository<Transfer, Integer> {

}
