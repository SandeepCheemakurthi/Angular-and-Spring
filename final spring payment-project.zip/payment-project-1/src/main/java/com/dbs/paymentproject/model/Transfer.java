package com.dbs.paymentproject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "transfer")
@Data

public class Transfer {
	
	@Id
	private int number;
	@Column
	private String sender;
	private int amount;
	private String bic;
	private String recevier;
	private String bank;

}
