package com.dbs.paymentproject.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.paymentproject.model.sender;
import com.dbs.paymentproject.repository.SenderRepository;

@Service
public class SenderService {
	
	@Autowired
	SenderRepository serviceRepository;
	
	public Optional<sender> getDetail(int id) {
		Optional<sender> temp = serviceRepository.findById(id);
		if (temp!=null) {
			return temp;
		}
		else {
			return null;
		}
	}
	
	public int getBalance(int id) {
		sender temp = serviceRepository.getById(id);
		return temp.getBalance();
	}
	
	public char getOd(int id) {
		sender temp = serviceRepository.getById(id);
		return temp.getOverdraft();
	}

}
