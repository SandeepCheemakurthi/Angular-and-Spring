package com.dbs.paymentproject.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.paymentproject.model.Transfer;
import com.dbs.paymentproject.model.sender;
import com.dbs.paymentproject.service.SenderService;
import com.dbs.paymentproject.service.TransferService;

@CrossOrigin(origins ="http://localhost:4200/")
@RestController
public class TransferController {

	@Autowired
	public TransferService transferService;
	@Autowired
	public SenderService senderService;
	
	public String addDetails(@RequestBody Transfer transfer) {
		transferService.createTransfer(transfer);
		return "Hi " + transfer.getSender() + " Your payment is successful";
	}
	
	@GetMapping("transfers")
	public List<Transfer> getTransfers(){
		
		return transferService.findAllDetails();
	}
	
	@PostMapping("/verify")
	public String getTransfer(@RequestBody Transfer transfer) {
		int id =transfer.getNumber();
		Optional<sender> test = senderService.getDetail(id);
		System.out.println(id);
		System.out.println(test);
		if(test.isEmpty()) {
			return "Account not exists";
		}
		else {
			int amount = transfer.getAmount();
			int balance = senderService.getBalance(id);
			System.out.println(amount);
			System.out.println(balance);
			if(amount<=balance) {
				return addDetails(transfer);
			}
			else {
				char overdraft = senderService.getOd(id);
				if(overdraft == 'y') {
					return addDetails(transfer);
				}
				else {
					return "Insufficient balance";
				}
			}
			//return "Account exists";
		}
	}
}
