package com.dbs.paymentproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.paymentproject.model.Transfer;
import com.dbs.paymentproject.repository.TransferRepository;

@Service
public class TransferService {

	@Autowired
	TransferRepository transferRepository;
	
	public Transfer createTransfer(Transfer transfer) {
		
		return transferRepository.save(transfer);
	}

	public List<Transfer> findAllDetails() {
		// TODO Auto-generated method stub
		return transferRepository.findAll();
	}
	
	public Transfer getDetails(int number) {
		
		Transfer temp =  transferRepository.getById(number);
		if (temp!=null) {
			return temp;
		}
		else {
			return null;
		}
	}
	
}
